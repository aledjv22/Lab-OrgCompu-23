Integrantes del grupo:
  -Victor Alejandro Díaz Jáuregui: 42785296
  -Aravena Aaron Lihuel:           36142043
  -Alejandro Nahuel Pitt Aparicio: 46173733

Descripción:
  El código genera la imagen de una carretera con arboles de copa circular, un auto azul y una camioneta blanca. 
  De pulsar la tecla W los arboles pasan a ser pinos, los vehiculos cambian de lugar y color. 
  De pulsar W se regresa a la imagen inicial.
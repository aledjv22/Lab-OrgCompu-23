Integrantes del grupo:
  -Victor Alejandro Díaz Jáuregui: 42785296
  -Aravena Aaron Lihuel:           36142043
  -Alejandro Nahuel Pitt Aparicio: 46173733

Descripción:
  La animacion muestra 3 paisajes distintos de rutas diferenciadas por los tipos de arboles y suelo, se pueden cambiar con las teclas W y S ya que son un ciclo bidireccional.
  La tecla A cambia las lineas punteadas del asfalto por lineas amarillas.
  Tecla D elimina y aparece uno a uno las camionetas mediante un ciclo repetitivo.
  El 'espacio' genera una secuencia de persecución entre un auto y una avioneta terminando el vehiculo eliminado por un misil. Tras detenerse la línea de ruta se habilita el uso de la W y S.